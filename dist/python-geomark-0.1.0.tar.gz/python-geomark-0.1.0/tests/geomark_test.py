import pytest


class TestGeoMark(object):
    def test_sample(self):
        assert 1 + 1 == 2
